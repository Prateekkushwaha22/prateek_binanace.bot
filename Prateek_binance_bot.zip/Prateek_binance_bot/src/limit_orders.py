import sys
import ccxt
import logging
import os

log_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
log_file = os.path.join(log_dir, 'bot.log')

logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

API_KEY = 'YOUR_BINANCE_API_KEY'
SECRET_KEY = 'YOUR_BINANCE_SECRET_KEY'


def run_limit_order():
    if len(sys.argv) < 5:
        print("\nCommand Error!")
        print("Usage: python src/limit_orders.py [SYMBOL] [SIDE] [AMOUNT] [PRICE]")
        return

    symbol = sys.argv[1].upper()
    side = sys.argv[2].lower()

    try:
        amount = float(sys.argv[3])
        price = float(sys.argv[4])

        if amount <= 0 or price <= 0:
            print("Error: Amount and Price must be positive.")
            return
    except ValueError:
        print("Error: Amount and Price must be numbers.")
        return

    print(f"\nPlacing LIMIT Order for {symbol} at ${price}...")
    logging.info(f"START: Limit Order request -> {side.upper()} {amount} {symbol} @ {price}")

    exchange = ccxt.binance({
        'apiKey': API_KEY,
        'secret': SECRET_KEY,
        'enableRateLimit': True,
        'options': {'defaultType': 'future'}
    })

    try:
        order = exchange.create_order(symbol, 'limit', side, amount, price)

        print(f"\nLIMIT ORDER PLACED!")
        print(f"--------------------------------")
        print(f"Order ID   : {order['id']}")
        print(f"Target Price: ${price}")
        print(f"Status     : {order['status'].upper()}")
        print(f"--------------------------------")

        logging.info(f"SUCCESS: Limit Order {order['id']} set at {price}")

    except Exception as e:
        print(f"\nFailed: {e}")
        logging.error(f"Limit Order Error: {str(e)}")


if __name__ == "__main__":
    run_limit_order()