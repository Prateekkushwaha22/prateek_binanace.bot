import sys
import ccxt
import logging
import os

# --- LOGGING SETUP ---
log_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
log_file = os.path.join(log_dir, 'bot.log')

logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

API_KEY = 'YOUR_API_KEY'
SECRET_KEY = 'YOUR_SECRET_KEY'


def run_oco_order():
    # COMMAND: python src/advanced/oco.py [SYMBOL] [SIDE] [AMOUNT] [TAKE_PROFIT_PRICE] [STOP_LOSS_PRICE]
    if len(sys.argv) < 6:
        print("\n Error: OCO ke liye price details chahiye!")
        print("Usage: python src/advanced/oco.py BTC/USDT buy 0.001 95000 85000")
        return

    symbol = sys.argv[1].upper()
    side = sys.argv[2].lower()  # 'buy' matlab Long, 'sell' matlab Short

    try:
        amount = float(sys.argv[3])
        tp_price = float(sys.argv[4])  # Profit Price
        sl_price = float(sys.argv[5])  # Stop Loss Price
    except ValueError:
        print("Error: Prices numbers mein likho.")
        return

    print(f"\n Setting up OCO Order for {symbol}...")
    print(f"Target Profit: ${tp_price} | Stop Loss: ${sl_price}")
    logging.info(f"START OCO: {symbol} TP:{tp_price} SL:{sl_price}")

    exchange = ccxt.binance({
        'apiKey': API_KEY,
        'secret': SECRET_KEY,
        'enableRateLimit': True,
        'options': {'defaultType': 'future'}
    })

    try:
        # Note: Futures me OCO complex hota hai, hum 2 alag order laga kar simulate kar rahe hain

        # 1. Take Profit Order
        tp_order = exchange.create_order(symbol, 'limit', 'sell' if side == 'buy' else 'buy', amount, tp_price)
        print(f"Take Profit Order Placed at ${tp_price}")

        # 2. Stop Loss Order
        # (Stop Market use kar rahe hain safety ke liye)
        params = {'stopPrice': sl_price}
        sl_order = exchange.create_order(symbol, 'stop_market', 'sell' if side == 'buy' else 'buy', amount,
                                         params=params)
        print(f" Stop Loss Order Placed at ${sl_price}")

        logging.info("OCO Orders placed successfully")

    except Exception as e:
        print(f" OCO Failed: {e}")
        logging.error(f"OCO Failed: {e}")


if __name__ == "__main__":
    run_oco_order()