import sys
import ccxt
import time
import logging
import os

# --- LOGGING SETUP ---
log_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
log_file = os.path.join(log_dir, 'bot.log')

logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

API_KEY = 'YOUR_API_KEY'
SECRET_KEY = 'YOUR_SECRET_KEY'


def run_twap_strategy():
    # COMMAND: python src/advanced/twap.py [SYMBOL] [SIDE] [TOTAL_AMOUNT] [CHUNKS] [INTERVAL_SECONDS]
    if len(sys.argv) < 6:
        print("\n Error: TWAP Strategy ke liye arguments kam hain!")
        print("Usage: python src/advanced/twap.py BTC/USDT buy 0.005 5 10")
        print("(Iska matlab: 0.005 BTC ko 5 baar mein kharido, har 10 second baad)")
        return

    symbol = sys.argv[1].upper()
    side = sys.argv[2].lower()

    try:
        total_amount = float(sys.argv[3])
        chunks = int(sys.argv[4])  # Kitne tukdo mein baatna hai
        interval = int(sys.argv[5])  # Kitne second rukna hai

        if chunks <= 0 or total_amount <= 0:
            print("Error: Amount aur Chunks positive hone chahiye.")
            return

    except ValueError:
        print("Error: Numbers sahi se likho.")
        return

    # Har baar kitna khareedna hai?
    amount_per_trade = total_amount / chunks

    print(f"\n Starting TWAP Strategy for {symbol}")
    print(f"Total: {total_amount} | Parts: {chunks} | Per Trade: {amount_per_trade}")
    logging.info(f"START TWAP: {side} {total_amount} {symbol} in {chunks} chunks")

    exchange = ccxt.binance({
        'apiKey': API_KEY,
        'secret': SECRET_KEY,
        'enableRateLimit': True,
        'options': {'defaultType': 'future'}
    })

    for i in range(1, chunks + 1):
        try:
            print(f"\n Executing Chunk {i}/{chunks}...")

            # Order Place Karna
            order = exchange.create_order(symbol, 'market', side, amount_per_trade)

            print(f"✅ Chunk {i} Success! ID: {order['id']}")
            logging.info(f"TWAP Chunk {i}/{chunks}: {order['id']}")

            if i < chunks:
                print(f" Waiting {interval} seconds for next chunk...")
                time.sleep(interval)

        except Exception as e:
            print(f" Chunk {i} Failed: {e}")
            logging.error(f"TWAP Chunk {i} Failed: {e}")
            # Loop nahi roka taaki agla chunk try kare

    print("\n TWAP Strategy Completed!")


if __name__ == "__main__":
    run_twap_strategy()