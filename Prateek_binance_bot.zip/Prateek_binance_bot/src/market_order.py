import sys
import ccxt
import logging
import os
from datetime import datetime

log_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
log_file = os.path.join(log_dir, 'bot.log')

logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

API_KEY = 'YOUR_BINANCE_API_KEY'
SECRET_KEY = 'YOUR_BINANCE_SECRET_KEY'


def run_market_order():
    if len(sys.argv) < 4:
        print("\nCommand Error!")
        print("Usage: python src/market_orders.py [SYMBOL] [SIDE] [AMOUNT]")
        return

    symbol = sys.argv[1].upper()
    side = sys.argv[2].lower()

    try:
        amount = float(sys.argv[3])
        if amount <= 0:
            print("Error: Amount must be positive.")
            return
    except ValueError:
        print("Error: Amount must be a number.")
        return

    print(f"\nConnecting to Binance Futures... ({symbol})")
    logging.info(f"START: Market Order request -> {side.upper()} {amount} {symbol}")

    try:
        exchange = ccxt.binance({
            'apiKey': API_KEY,
            'secret': SECRET_KEY,
            'enableRateLimit': True,
            'options': {'defaultType': 'future'}
        })

    except Exception as e:
        print(f"Connection Error: {e}")
        logging.error(f"Connection Failed: {str(e)}")
        return

    try:
        order = exchange.create_order(symbol, 'market', side, amount)

        print(f"\nSUCCESS! Order Placed.")
        print(f"--------------------------------")
        print(f"Order ID   : {order['id']}")
        print(f"Type       : MARKET")
        print(f"Status     : {order['status'].upper()}")
        print(f"--------------------------------")

        logging.info(f"SUCCESS: Order ID {order['id']} placed for {symbol}")

    except Exception as e:
        print(f"\nOrder Failed: {e}")
        logging.error(f"Order Execution Error: {str(e)}")


if __name__ == "__main__":
    run_market_order()