# Binance Futures Trading Bot

This is a CLI-based trading bot for Binance USDT-M Futures. It allows users to place Market and Limit orders directly from the terminal.

##  Project Structure
src/market_orders.py`: Script to place market orders.
src/limit_orders.py`: Script to place limit orders.
 bot.log`: Automatically records all transaction history and errors.

##  Prerequisites
1. **Python 3.x** must be installed.
2. Install the required library:
   bash
   pip install ccxt


 *  `src/advanced/twap.py`: (Bonus) Time-Weighted Average Price strategy.
* `src/advanced/oco.py`: (Bonus) One-Cancels-the-Other order simulation.

   